import { useState } from 'react';

import discoverLogo from '../../assets/images/discover-logo.svg';
import matchLogo from '../../assets/images/match-logo.svg';
import matchImage from '../../assets/images/swiper-match1.png';
import PhoneSwiper from '../PhoneSwiper';
import { StyledSlideTo } from './styles';

export default function SlideTo({ discover }) {

    const [mobileMode, setMobileMode] = useState(false);


    return (
        <StyledSlideTo>
            <div className="container">
                <div className="col-12 col-xl-10 mx-auto">
                    <img src={discover ? discoverLogo : matchLogo} alt="discover" className='d-none d-md-block' />
                    <h2 className='text-center'>Swipe to {discover ? 'Discover' : 'Match'}</h2>
                    <p className='text-colored mt-4 text-center'>
                        Not sure of where to begin, or looking for a product to
                        create a certain effect, or help alleviate an ailment?
                    </p>
                </div>
                <div className='actions d-flex justify-content-center'>
                    <div onClick={() => setMobileMode(false)}>
                        <span>DESKTOP</span>
                    </div>
                    <div onClick={() => setMobileMode(true)}>
                        <span> MOBILE</span>
                    </div>
                </div>

                {discover ?
                    <div className='col-10 mx-auto col-md'>
                        <PhoneSwiper switchMobileMode={mobileMode} />
                    </div>
                    :
                    <div className='w-100 position-relative'>
                        <img src={mobileMode ? discoverLogo : matchImage} alt="match" className='w-100' />
                    </div>
                }
            </div>
        </StyledSlideTo>
    )
}