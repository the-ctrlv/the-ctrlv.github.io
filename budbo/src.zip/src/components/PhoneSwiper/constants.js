import r2Phone1 from '../../assets/images/r2-phone1.png';
import r2Phone2 from '../../assets/images/r2-phone2.png';
import r2Phone3 from '../../assets/images/r2-phone3.png';
import r4Phone1 from '../../assets/images/r4-phone1.png';
import r4Phone2 from '../../assets/images/r4-phone2.png';
import r4Phone3 from '../../assets/images/r4-phone3.png';

export const mockReason2Content = [
    r2Phone1, r2Phone2, r2Phone3
]

export const mockReason4Content = [
    r4Phone1, r4Phone2, r4Phone3
]