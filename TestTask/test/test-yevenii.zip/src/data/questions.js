export const MOCK_QUESTIONS = [
	{
		title: "How old your elder brother was 10 years before you was born, mate?",
		options: [
			"10 years",
			"16 years",
			"14 years",
			"12 years"
		],
		correctAnswer: "14 years",
		price: "500$"
	},
	{
		title: "22222How old your elder brother was 10 years before you was born, mate?",
		options: [
			"10 years",
			"16 years",
			"14 years",
			"12 years"
		],
		correctAnswer: "14 years",
		price: "1000$"
	},
	{
		title: "3333How old your elder brother was 10 years before you was born, mate?",
		options: [
			"10 years",
			"16 years",
			"14 years",
			"12 years"
		],
		correctAnswer: "14 years",
		price: "2,000$"
	},
	{
		title: "44444How old your elder brother was 10 years before you was born, mate?",
		options: [
			"10 years",
			"16 years",
			"14 years",
			"12 years"
		],
		correctAnswer: "14 years",
		price: "4,000$"
	},
	{
		title: "55555How old your elder brother was 10 years before you was born, mate?",
		options: [
			"10 years",
			"16 years",
			"14 years",
			"12 years"
		],
		correctAnswer: "14 years",
		price: "8,000$"
	},
	{
		title: "6666How old your elder brother was 10 years before you was born, mate?",
		options: [
			"10 years",
			"16 years",
			"14 years",
			"12 years"
		],
		correctAnswer: "14 years",
		price: "16,000$"
	},
	{
		title: "7777How old your elder brother was 10 years before you was born, mate?",
		options: [
			"10 years",
			"16 years",
			"14 years",
			"12 years"
		],
		correctAnswer: "14 years",
		price: "32,000$"
	},
	{
		title: "8888How old your elder brother was 10 years before you was born, mate?",
		options: [
			"10 years",
			"16 years",
			"14 years",
			"12 years"
		],
		correctAnswer: "14 years",
		price: "64,000$"
	},
	{
		title: "9999How old your elder brother was 10 years before you was born, mate?",
		options: [
			"10 years",
			"16 years",
			"14 years",
			"12 years"
		],
		correctAnswer: "14 years",
		price: "125,000$"
	},
	{
		title: "10How old your elder brother was 10 years before you was born, mate?",
		options: [
			"10 years",
			"16 years",
			"14 years",
			"12 years"
		],
		correctAnswer: "14 years",
		price: "250,000$"
	},
	{
		title: "11How old your elder brother was 10 years before you was born, mate?",
		options: [
			"10 years",
			"16 years",
			"14 years",
			"12 years"
		],
		correctAnswer: "14 years",
		price: "500,000$"
	},
	{
		title: "12How old your elder brother was 10 years before you was born, mate?",
		options: [
			"10 years",
			"16 years",
			"14 years",
			"12 years"
		],
		correctAnswer: "14 years",
		price: "1,000,000$"
	},
]
